# Makes 'backend.app' a proper package

